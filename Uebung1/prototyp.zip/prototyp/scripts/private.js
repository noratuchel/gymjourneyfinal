'use strict';

function revealMessage(){
    document.getElementById("hiddenMessage").style.display= 'block';
    document.getElementById("read").innerHTML=" ";
}
function revealMessage2(){
    document.getElementById("hiddenMessage2").style.display= 'block';
     document.getElementById("read2").innerHTML=" ";
}

